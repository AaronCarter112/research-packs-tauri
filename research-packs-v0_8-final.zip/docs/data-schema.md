# Data Schema
- timecoded_points: JSON mapping HH:MM:SS -> text
- Entities exported across: entities_people, entities_orgs, entities_places, entity_confidence_scores
